package com.example.personas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btn: Button = findViewById(R.id.btn_menu_insertar)
        btn.setOnClickListener{
            val intent = Intent(this,Insertar::class.java)
            startActivity(intent)
        }

        val btnbuscar: Button = findViewById(R.id.btn_menu_buscar)
        btnbuscar.setOnClickListener{
            val intent: Intent = Intent(this,Buscar::class.java)
            startActivity(intent)
        }


        val btncreditos: Button = findViewById(R.id.btn_menu_creditos)
        btncreditos.setOnClickListener{
            val intent: Intent = Intent(this,Creditos::class.java)
            startActivity(intent)
        }

        val btneliminar: Button = findViewById(R.id.btn_menu_borrar)
        btneliminar.setOnClickListener{
            val intent: Intent = Intent(this,Borrar::class.java)
            startActivity(intent)
        }
    }
}