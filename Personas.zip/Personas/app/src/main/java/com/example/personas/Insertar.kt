 package com.example.personas

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONObject

 class Insertar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insertar)

        val etCodigo = findViewById<EditText>(R.id.txt_insertar_codigo)
        val etNombre = findViewById<EditText>(R.id.txt_insertar_nombre)
        val etApellido = findViewById<EditText>(R.id.txt_insertar_apellido)
        val etDireccion = findViewById<EditText>(R.id.txt_insertar_direccion)
        val etTelefono = findViewById<EditText>(R.id.txt_insertar_telefono)
        val btnGuardar = findViewById<Button>(R.id.btn_insertar_insertar)



        btnGuardar.setOnClickListener {
            val requestQueue = Volley.newRequestQueue(this);
            var url = "https://proyectos-efpem-marius.000webhostapp.com/insertar.php?"
            url += "codigo=" + etCodigo.getText().toString()
            url += "&nombre=" + etNombre.getText().toString()
            url += "&apellido=" + etApellido.getText().toString()
            url += "&direccion=" + etDireccion.getText().toString()
            url += "&telefono=" + etTelefono.getText().toString()

            //https://proyectos-efpem-marius.000webhostapp.com/insertar.php?codigo=101&nombre=Cod&apellido=ciento&direccion=zona4&telefono=233
            val stringRequest = StringRequest(Request.Method.GET, url,
                { response ->
                    val jsonArray = JSONArray(response)
                    val objeto = JSONObject(jsonArray.getString(0))

                    Log.d("Datos", objeto.toString())
                    Log.d("Codigo: ", objeto.getString("codigo"))
                    Log.d("Nombre: ", objeto.getString("nombre"))
                    Log.d("Apellido: ", objeto.getString("apellido"))
                    Log.d("Direccion: ", objeto.getString("direccion"))
                    Log.d("Telefono: ", objeto.getString("telefono"))

                    Toast.makeText(this, "Elemento insertado", Toast.LENGTH_SHORT).show()
                },
                { error ->
                    Toast.makeText(this, "Error en el servicio", Toast.LENGTH_SHORT).show()
                })
            requestQueue.add(stringRequest)

        }

        val btn: Button = findViewById(R.id.btn_insertar_regresar)
        btn.setOnClickListener{
            val intent: Intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }


    }
}





