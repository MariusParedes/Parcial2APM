package com.example.personas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import android.widget.EditText
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONArray
import org.json.JSONObject

class Buscar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_buscar)

        val etCodigo = findViewById<EditText>(R.id.txt_buscar_codigo)
        val etNombre = findViewById<EditText>(R.id.txt_buscar_nombre)
        val etApellido = findViewById<EditText>(R.id.txt_buscar_apellido)
        val etDireccion = findViewById<EditText>(R.id.txt_buscar_direccion)
        val etTelefono = findViewById<EditText>(R.id.txt_buscar_telefono)
        val btnActualizar = findViewById<Button>(R.id.btn_buscar_actualizar)
        val btnBuscar = findViewById<Button>(R.id.btn_buscar_buscar)
        val chkHabilitar = findViewById<CheckBox>(R.id.chk_buscar_habilitar)

        btnBuscar.setOnClickListener{
            val requestQueue = Volley.newRequestQueue(this)
            var url = "https://proyectos-efpem-marius.000webhostapp.com/buscar.php?"
            url += "codigo="+etCodigo.getText().toString()

            val stringRequest = StringRequest(Request.Method.GET, url,
                Response.Listener { response ->
                val jsonArray = JSONArray(response)
                var objetoJson = JSONObject(jsonArray.getString(0))
                etNombre.setText(objetoJson.getString("nombre"))
                etApellido.setText(objetoJson.getString("apellido"))
                etDireccion.setText(objetoJson.getString("direccion"))
                etTelefono.setText(objetoJson.getString("telefono"))
                },
                Response.ErrorListener { error ->
                    Toast.makeText(this,"Error en el servicio web",Toast.LENGTH_SHORT).show()
                })
            requestQueue.add(stringRequest)
        }

        btnActualizar.setOnClickListener {
            val requestQueue = Volley.newRequestQueue(this)
            var url= "https://proyectos-efpem-marius.000webhostapp.com/actualizar.php?"
            url += "codigo=" + etCodigo.getText().toString()
            url += "&nombre=" + etNombre.getText().toString()
            url += "&apellido=" + etApellido.getText().toString()
            url += "&direccion=" + etDireccion.getText().toString()
            url += "&telefono=" + etTelefono.getText().toString()

            val stringRequest = StringRequest(Request.Method.GET, url,
                Response.Listener<String> { response ->
                    val jsonArray = JSONArray(response)
                    var objetoJson = JSONObject(jsonArray.getString(0))
                    Toast.makeText(this, "Datos modificados", Toast.LENGTH_SHORT).show()
                },
                Response.ErrorListener { error ->
                    Toast.makeText(this,"Error al modificar",Toast.LENGTH_SHORT).show()
                })

            requestQueue.add(stringRequest)




        }



        chkHabilitar.setOnClickListener {
            if(chkHabilitar.isChecked){
                btnActualizar.isEnabled=true
            }else
                btnActualizar.isEnabled = false

        }






        val btn: Button = findViewById(R.id.btn_buscar_regresar)
        btn.setOnClickListener{
            val intent: Intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }

    }
}