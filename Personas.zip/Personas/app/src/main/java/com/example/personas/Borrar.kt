package com.example.personas

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class Borrar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_borrar)

        val etCodigo = findViewById<EditText>(R.id.txt_borrar_codigo)
        val btnBorrar = findViewById<Button>(R.id.btn_borrar_borrar)


        btnBorrar.setOnClickListener{
            val requestQueue = Volley.newRequestQueue(this)
            val url = "https://proyectos-efpem-marius.000webhostapp.com/eliminar.php?codigo=" +etCodigo.getText().toString()
                       //https://proyectos-efpem-marius.000webhostapp.com/eliminar.php?codigo=101
            val stringRequest = StringRequest(Request.Method.GET, url,
                Response.Listener<String>{ response ->
                    Toast.makeText(this,"Registro Eliminado",Toast.LENGTH_SHORT).show()
                },
                Response.ErrorListener { error ->
                    Toast.makeText(this,"Error al eliminar",Toast.LENGTH_SHORT).show()
                })
            requestQueue.add(stringRequest)
        }










        val btn: Button = findViewById(R.id.btn_borrar_regresar)
        btn.setOnClickListener{
            val intent: Intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }


    }
}